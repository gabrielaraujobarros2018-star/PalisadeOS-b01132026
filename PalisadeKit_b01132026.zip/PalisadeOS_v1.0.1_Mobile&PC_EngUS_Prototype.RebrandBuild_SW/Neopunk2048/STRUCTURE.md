# PalisadeOS — STRUCTURE.md  
Version: 1.0.1  
Status: Architectural baseline frozen

---

## 1. Structural Philosophy

PalisadeOS is structured around **explicit responsibility layers**.  
No directory exists as a convenience; every layer has a defined scope, lifecycle role, and interaction boundary.

The system avoids monolithic coupling and avoids cloning Linux or Windows layouts.  
Instead, it follows a **lattice model**: independent domains connected through declared bridges and runtime contracts.

The structure is designed to support:
- Deterministic boot
- Clear execution flow
- Debuggable failure states
- Future extensibility without refactors

---

## 2. Boot and Entry Model

The boot process is split into **firmware-specific loaders** and **OS-neutral handoff logic**.

Responsibilities:
- Firmware handling (BIOS / UEFI)
- CPU mode transitions (16 → 32 → 64-bit where required)
- Memory map acquisition
- Kernel image loading
- Ramdisk attachment

The bootloader does not initialize devices beyond what is strictly necessary.  
All real hardware ownership begins inside the kernel.

---

## 3. Kernel Domain (NeoKern Lineage)

The kernel is responsible for:
- CPU scheduling
- Virtual memory
- Interrupt handling
- Syscall dispatch
- Core hardware drivers
- Process and thread control

The kernel **does not**:
- Parse configuration files
- Launch services directly
- Know about GUI internals

All non-core behavior is delegated upward through runtime interfaces.

Supported targets:
- x86 (32-bit)
- x86_64 (64-bit)
- AMD and Intel desktop-class processors

---

## 4. Ramdisk OS Layer

The ramdisk represents the **minimum viable operating environment**.

It provides:
- Early userland utilities
- Initial configuration
- Runtime bootstrap components
- Recovery access if the root system fails

The ramdisk is intentionally self-contained and replaceable.

---

## 5. System Lattice (POSIX-Aligned)

Instead of a traditional “everything in /etc” model, PalisadeOS uses a **system lattice**:

- Configuration is segmented by responsibility
- Runtime state is separated from static definition
- Tools, diagnostics, and inspection utilities are first-class citizens

POSIX compatibility is treated as a **contract**, not a clone.  
Where POSIX is insufficient, PalisadeOS extends behavior without breaking compliance.

---

## 6. Runtime Execution Layer

The runtime layer is the **activation engine** of the OS.

Its responsibilities include:
- Interpreting service definitions
- Loading bridges between kernel, GUI, shell, and system
- Managing IPC channels
- Synchronizing lifecycle states
- Enforcing execution policies
- Handling fault recovery and safe modes

Without the runtime layer, system components exist but cannot cooperate.

---

## 7. Integration Layer (Palisade Core)

The integration layer is the **system nervous system**.

It defines:
- OS identity and versioning
- Lifecycle transitions (boot, session, shutdown)
- Profiles and operating modes
- Service visibility
- Compatibility declarations
- Recovery metadata

This layer does not execute logic directly; it **declares truth** that other layers act upon.

---

## 8. GUI and Shell Model

The GUI and shell are peers, not parent/child.

- The GUI is a compositor-driven environment
- The shell is a feature-rich command environment capable of GUI interaction
- Both communicate through runtime bridges
- Neither assumes the other must exist

This enables:
- Headless operation
- GUI-only sessions
- Recovery shells
- Debug sessions without graphics

---

## 9. Registry-Like System (Non-Windows)

System state that must be queryable, versioned, or inspected lives in a **hierarchical, file-backed registry model**.

Characteristics:
- POSIX-compliant
- Human-readable where possible
- Binary where required for integrity
- No global monolithic database
- No Windows Registry semantics copied

This system enables inspection, tooling, and rollback without opaque state.

---

## 10. Failure and Recovery Design

Failure is treated as a **first-class condition**, not an exception.

The structure supports:
- Safe mode entry
- Rollback points
- Fault capture
- Post-mortem diagnostics
- Partial system activation

A broken GUI does not prevent shell access.  
A broken shell does not prevent recovery tools.

---

## 11. Versioning and Stability

Version 1.0.1 freezes:
- Directory responsibilities
- Layer boundaries
- Execution flow

Future versions may:
- Add new services
- Extend runtime capabilities
- Improve tooling

But must not:
- Collapse layers
- Introduce hidden coupling
- Break declared contracts

---

## 12. Final Statement

PalisadeOS is structured to **survive implementation mistakes**.

The goal of this structure is not speed or novelty, but:
- Clarity
- Longevity
- Control
- Debuggability

With the structure frozen, implementation becomes an engineering task — not a guessing game.