This is the main roots.

# Root Architecture

## Assembly

- x86-64 Assembly

## Kernel

- Our Own custom lightweight hybrid kernel: "Neocyber 2027"
- Lightweight
- Adaptable into Mobile and Embedded devices Beyond just PC

## Architecture

- Adaptable into Mobile, beyond just PC
- POSIX-Compliant