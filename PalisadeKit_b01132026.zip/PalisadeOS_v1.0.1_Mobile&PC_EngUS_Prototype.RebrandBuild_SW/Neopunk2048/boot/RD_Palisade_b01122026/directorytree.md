RD_NMOS_b01122026/
├── etc/
│   ├── hostname
│   ├── passwd
│   ├── group
│   └── fstab
│
├── system/
│   ├── init.cfg
│   ├── logging.cfg
│   ├── limits.cfg
│   └── kernel.cfg
│
├── data/
│   ├── system.dat
│   ├── kern.dat
│   └── fs.dat
│
├── proc/
│   ├── cpuinfo
│   ├── meminfo
│   ├── uptime
│   └── mounts
│
├── bin/
│   ├── sh
│   ├── ls
│   └── echo
│
├── gui/
│   ├── theme.cfg
│   └── layout.cfg
│
└── init/
    └── rcS